import unittest
from cast.application.test import run
from sqlalchemy import create_engine

class Test(unittest.TestCase):


    def test_basic(self):
        run(kb_name='dns_local', application_name='DSN',
        engine=create_engine("postgresql+pg8000://operator:CastAIP@GAICVMCSS7:2280/postgres"))


if __name__ == "__main__":
    unittest.main()

