import unittest
from cast.analysers.test import JEETestAnalysis

class Test(unittest.TestCase):


    def testName_01(self):
        analysis = JEETestAnalysis()
        analysis.add_dependency(r'C:\ProgramData\CAST\CAST\Extensions\com.castsoftware.jee.1.3.5-funcrel')
        analysis.add_selection('test_01')
        analysis.set_verbose()
        analysis.run()


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()