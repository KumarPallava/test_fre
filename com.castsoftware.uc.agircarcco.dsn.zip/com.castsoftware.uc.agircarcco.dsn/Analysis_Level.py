import cast.analysers.jee
#import xml.etree.ElementTree as ET
import lxml.etree as ET
from cast.analysers import log, CustomObject, external_link, create_link, Bookmark
from builtins import str

class AnalysisLevel(cast.analysers.jee.Extension):
    
    
    def start_analysis(self,options):
        #log.info('test start')
        options.handle_xml_with_xpath('//beans')
            
    
    def start_xml_file(self, file):   
        #log.info('test start') 
        xmlfilepath = file.get_path()
        log.info('scanning file %s' % xmlfilepath)
        if not file.get_path() or len(xmlfilepath.strip()) == 0 or 'LargeStorageArea' in xmlfilepath: 
            return    
          
        tree = ET.parse(xmlfilepath)
        root = tree.getroot()

#         log.info("ROOT TAG ::: "  + str(root.tag))
#         for children in root:
#             log.info('1*')
#             log.info(str(children.tag))
#             log.info(str(children.attrib))
            
        for query in root.findall(r"./{http://www.springframework.org/schema/util}map/{http://www.springframework.org/schema/beans}entry"):
            #log.info('**2**')
            #log.info(str(query.tag)) #{http://www.springframework.org/schema/beans}entry
            #log.info(str(query.attrib))#{'key': 'insertionStatutCommRngd', 'value': "INSERT INTO t_drt_sta
            
            key = None
            sql = None   
                     
            for k, v in query.attrib.items():
                if str(k) == 'key':
                    key = v
                if str(k) == 'value':
                    sql = v
                
            sqlquery = CustomObject()
            sqlquery.set_name(key)
            sqlquery.set_type('CAST_SQL_NamedQuery')
            sqlquery.set_parent(file)
            sqlquery.save()   
            sqlquery.save_position(Bookmark(file, query.sourceline, 1, query.sourceline, 100))
            sqlquery.save_property("CAST_SQL_MetricableQuery.sqlQuery", sql)
            log.info("TEST OK")
            for embedded in external_link.analyse_embedded(sql):
                for t in embedded.types: 
                    create_link(t, sqlquery, embedded.callee)  
                    